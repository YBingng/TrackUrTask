import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class TimeProvider with ChangeNotifier {
  String _time = '';
  String _formattedDate = '';

  String get time => _time;
  String get formattedDate => _formattedDate;

  TimeProvider() {
    setTime();
  }

  void setTime() {
    final now = DateTime.now();
    _time = DateFormat('HH:mm').format(now);
    _formattedDate = DateFormat('dd MMM').format(now);
    notifyListeners();
}
}