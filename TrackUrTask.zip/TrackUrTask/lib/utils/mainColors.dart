import 'package:flutter/material.dart';

class maincolors{
  
  // Color.fromARGB(255, 124, 114, 156),
  static const color1 =  Color.fromARGB(255, 147,139,174);
  // rgba(140,155,173,255)
  static const  color2 = Color.fromARGB(255, 140,155,173);
  // rgba(138,174,140,255)
  static const color3 =Color.fromARGB(255, 138,174,140);
// rgba(172,139,159,255)
  static const color4 = Color.fromARGB(172,139,159,140);

  static const color1Dark =  Color.fromARGB(255, 124, 114, 156);
  // rgba(140,155,173,255)
  static const  color2Dark = Color.fromARGB(255, 86, 120, 131);
  // rgba(138,174,140,255)
  static const color3Dark =Color.fromARGB(255, 90, 143, 93);
// rgba(172,139,159,255)
  static const color4Dark = Color.fromARGB(172, 98, 139, 100);
  
}