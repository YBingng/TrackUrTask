import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class TaskCard extends StatefulWidget {
  final String taskId;
  final String title;
  final String description;
  final String status;
  final DateTime startDateTime;
  final DateTime endDateTime;
  final Color clr;
  final bool isShared;
  final String? sharedUserName;

  const TaskCard({
    super.key,
    required this.taskId,
    required this.title,
    required this.description,
    required this.status,
    required this.startDateTime,
    required this.endDateTime,
    required this.clr,
    this.isShared = false,
    this.sharedUserName,
  });

  @override
  State<TaskCard> createState() => _TaskCardState();
}

class _TaskCardState extends State<TaskCard> {
  // Define all valid status options (now only 3)
  static const List<String> _validStatuses = [
    'Pending',
    'In Progress',
    'Completed'
  ];

  late String _currentStatus;

  @override
  void initState() {
    super.initState();
    // Sanitize and validate the initial status
    _currentStatus = _sanitizeStatus(widget.status);
    debugPrint('Initial status: ${widget.status}, Using: $_currentStatus');
  }

  String _sanitizeStatus(String status) {
    // Trim whitespace and check for valid status
    final cleanStatus = status.trim();
    return _validStatuses.contains(cleanStatus) ? cleanStatus : 'Pending';
  }

  String _formatTime(DateTime time) {
    return DateFormat('h:mm a').format(time);
  }

  String _getDuration() {
    final duration = widget.endDateTime.difference(widget.startDateTime);
    if (duration.inHours > 0) {
      return '${duration.inHours}h ${duration.inMinutes.remainder(60)}m';
    }
    return '${duration.inMinutes}m';
  }

  Future<void> _updateStatus(String newStatus) async {
    if (newStatus == _currentStatus) return;

    try {
      // First update UI for immediate feedback
      setState(() {
        _currentStatus = newStatus;
      });

      // Then update Firestore
      await FirebaseFirestore.instance
          .collection('tasks')
          .doc(widget.taskId)
          .update({'status': newStatus});

    } catch (e) {
      debugPrint('Error updating status: $e');
      // Revert UI if update fails
      setState(() {
        _currentStatus = _sanitizeStatus(widget.status);
      });
      
      // Show error to user
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to update status: ${e.toString()}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Final validation of current status before building
    final displayedStatus = _validStatuses.contains(_currentStatus)
        ? _currentStatus
        : 'Pending';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      child: Container(
        decoration: BoxDecoration(
          color: widget.clr,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 6,
              offset: const Offset(0, 3),
            )
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.title,
                          style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (widget.isShared && widget.sharedUserName != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              'Shared by ${widget.sharedUserName}',
                              style: GoogleFonts.poppins(
                                color: Colors.white.withOpacity(0.8),
                                fontSize: 12,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  DropdownButton<String>(
                    value: displayedStatus,
                    dropdownColor: widget.clr,
                    underline: const SizedBox(),
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                    icon: const Icon(Icons.arrow_drop_down, color: Colors.white),
                    items: _validStatuses.map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(
                          value,
                          style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                        ),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      if (newValue != null) {
                        _updateStatus(newValue);
                      }
                    },
                  ),
                ],
              ),
              const SizedBox(height: 8),
              if (widget.description.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    widget.description,
                    style: GoogleFonts.poppins(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 14,
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _formatTime(widget.startDateTime),
                        style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      Text(
                        'Start',
                        style: GoogleFonts.poppins(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      _getDuration(),
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _formatTime(widget.endDateTime),
                        style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      Text(
                        'End',
                        style: GoogleFonts.poppins(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}