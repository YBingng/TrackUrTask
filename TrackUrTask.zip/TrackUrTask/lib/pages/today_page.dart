import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:calender_app/provider/time_provider.dart';
import 'package:calender_app/pages/calender_page.dart';
import 'package:calender_app/pages/add_task.dart';
import 'user_profile.dart';

class TodayPage extends StatefulWidget {
  const TodayPage({super.key});

  @override
  State<TodayPage> createState() => _TodayPageState();
}

class _TodayPageState extends State<TodayPage> {
  final PanelController _panelController = PanelController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _showTasks = false;
  List<Map<String, dynamic>> _tasks = [];
  List<Map<String, dynamic>> _upcomingTasks = [];
  int _upcomingTaskCount = 0;

  @override
  void initState() {
    super.initState();
    final timeProvider = Provider.of<TimeProvider>(context, listen: false);
    Timer.periodic(const Duration(seconds: 1), (timer) {
      timeProvider.setTime();
    });
    _fetchTasks();
  }

  DateTime _getTodayStart() =>
      DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day);
  DateTime _getTodayEnd() => DateTime(DateTime.now().year, DateTime.now().month,
      DateTime.now().day, 23, 59, 59);
  DateTime _getTwoHoursLater() => DateTime.now().add(const Duration(hours: 2));

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Completed':
        return Colors.green.shade400;
      case 'In Progress':
        return Colors.blue.shade400;
      case 'Overdue':
        return Colors.red.shade400;
      default:
        return Colors.blue.shade200;
    }
  }

  Future<void> _fetchTasks() async {
    User? user = _auth.currentUser;
    if (user == null) return;

    String userID = user.uid;
    List<Map<String, dynamic>> fetchedTasks = [];
    List<Map<String, dynamic>> upcomingTasks = [];

    try {
      // Get current user's tasks
      QuerySnapshot userTasks = await _firestore
          .collection('users')
          .doc(userID)
          .collection('taskID')
          .where('startDateTime',
              isGreaterThanOrEqualTo: Timestamp.fromDate(_getTodayStart()))
          .where('startDateTime',
              isLessThanOrEqualTo: Timestamp.fromDate(_getTodayEnd()))
          .get();

      for (var doc in userTasks.docs) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        data['id'] = doc.id;
        data['isShared'] = false;

        DateTime startTime = (data['startDateTime'] as Timestamp).toDate();
        if (startTime.isAfter(DateTime.now())) {
          // Fixed missing parenthesis
          upcomingTasks.add(data);
        }

        fetchedTasks.add(data);
      }

      // Get shared users' tasks
      QuerySnapshot sharedUsers = await _firestore
          .collection('users')
          .where('sharedWith', arrayContains: userID)
          .get();

      for (var doc in sharedUsers.docs) {
        String sharedUserID = doc.id;

        QuerySnapshot sharedTasks = await _firestore
            .collection('users')
            .doc(sharedUserID)
            .collection('taskID')
            .where('startDateTime',
                isGreaterThanOrEqualTo: Timestamp.fromDate(_getTodayStart()))
            .where('startDateTime',
                isLessThanOrEqualTo: Timestamp.fromDate(_getTodayEnd()))
            .get();

        for (var doc in sharedTasks.docs) {
          Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
          data['id'] = doc.id;
          data['isShared'] = true;
          data['sharedUserName'] = _firestore
              .collection('users')
              .doc(sharedUserID)
              .get()
              .then((userDoc) => userDoc.data()?['name'] ?? 'Unknown User');

          DateTime startTime = (data['startDateTime'] as Timestamp).toDate();
          if (startTime.isAfter(DateTime.now())) {
            upcomingTasks.add(data);
          }

          fetchedTasks.add(data);
        }
      }

      setState(() {
        _tasks = fetchedTasks;
        _upcomingTasks = upcomingTasks.where((task) {
          DateTime startTime = (task['startDateTime'] as Timestamp).toDate();
          return startTime.isBefore(_getTwoHoursLater());
        }).toList();
        _upcomingTaskCount = _upcomingTasks.length;
      });
    } catch (e) {
      print("Error fetching tasks: $e");
    }
  }

  void _togglePanel() {
    setState(() {
      _showTasks = !_showTasks;
      _showTasks ? _panelController.open() : _panelController.close();
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.blue,
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => AddTaskPage()),
        ).then((_) => _fetchTasks()),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: SlidingUpPanel(
        controller: _panelController,
        maxHeight: screenHeight * 0.5,
        minHeight: 0,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
        panel: _buildTasksPanel(),
        body: _buildMainContent(),
      ),
    );
  }

  Widget _buildTasksPanel() {
    return Padding(
      padding: EdgeInsets.only(top: 20.h, left: 5.w, right: 5.w),
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Today's Tasks",
                    style: GoogleFonts.poppins(
                        fontSize: 18.sp, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          SizedBox(height: 20.h),
          Expanded(
            child: _tasks.isEmpty
                ? Center(
                    child: Text('No tasks for today!',
                        style: GoogleFonts.poppins(fontSize: 16.sp)))
                : ListView.builder(
                    padding: EdgeInsets.only(bottom: 20.h),
                    itemCount: _tasks.length,
                    itemBuilder: (context, index) {
                      final task = _tasks[index];
                      return _TaskCard(
                        taskId: task['id'],
                        title: task['title'] ?? 'Untitled',
                        description: task['description'] ?? '',
                        status: task['status'] ?? '',
                        startTime:
                            (task['startDateTime'] as Timestamp).toDate(),
                        endTime: (task['endDateTime'] as Timestamp).toDate(),
                        color: _getStatusColor(task['status']),
                        isShared: task['isShared'] ?? false,
                        sharedUserName: task['sharedUserName'],
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildMainContent() {
    return SafeArea(
      child: Container(
        height: ScreenUtil().screenHeight,
        width: ScreenUtil().screenWidth,
        color: Colors.green.shade100,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 30.w, vertical: 10.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 30.h),
              _buildTopBar(),
              SizedBox(height: 30.h),
              Consumer<TimeProvider>(
                builder: (context, provider, _) => Text(
                    DateFormat('EEEE').format(DateTime.now()),
                    style: GoogleFonts.poppins(fontSize: 20.sp)),
              ),
              SizedBox(height: 20.h),
              if (_upcomingTaskCount > 0)
                Container(
                  padding:
                      EdgeInsets.symmetric(vertical: 8.h, horizontal: 16.w),
                  decoration: BoxDecoration(
                    color: Colors.orange.shade100,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.notifications_active,
                          color: Colors.orange.shade800),
                      SizedBox(width: 8.w),
                      Text(
                        '$_upcomingTaskCount tasks in next 2 hours',
                        style: GoogleFonts.poppins(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w500,
                          color: Colors.orange.shade800,
                        ),
                      ),
                    ],
                  ),
                ),
              SizedBox(height: 20.h),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Consumer<TimeProvider>(
                      builder: (context, provider, _) => Column(
                        children: [
                          Text(provider.time,
                              style: GoogleFonts.poppins(
                                  fontSize: 70.sp,
                                  fontWeight: FontWeight.w500)),
                          SizedBox(height: 10.h),
                          Text(provider.formattedDate,
                              style: GoogleFonts.poppins(fontSize: 24.sp)),
                        ],
                      ),
                    ),
                    SizedBox(height: 40.h),
                    FloatingActionButton(
                      onPressed: _togglePanel,
                      backgroundColor: Colors.green.shade300,
                      child: Icon(
                        _showTasks
                            ? Icons.keyboard_arrow_down
                            : Icons.keyboard_arrow_up,
                        size: 36.sp,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              height: 50.h,
              decoration: BoxDecoration(
                  color: Colors.green.shade300,
                  borderRadius: BorderRadius.circular(24)),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Center(
                  child: Text("Today",
                      style: GoogleFonts.poppins(
                          color: Colors.white, fontSize: 16.sp)),
                ),
              ),
            ),
            SizedBox(width: 10.w),
            GestureDetector(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const CalenderPage())),
              child: Container(
                height: 50.h,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all()),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: Center(
                    child: Text("Calendar",
                        style: GoogleFonts.poppins(fontSize: 16.sp)),
                  ),
                ),
              ),
            )
          ],
        ),
        GestureDetector(
          onTap: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => UserProfilePage())),
          child: Container(
            height: 50.h,
            width: 50.w,
            decoration: BoxDecoration(
                border: Border.all(),
                borderRadius: BorderRadius.circular(50),
                color: Colors.lightBlue.shade100),
            child: Center(child: Icon(Icons.person, size: 24.sp)),
          ),
        ),
      ],
    );
  }
}

class _TaskCard extends StatelessWidget {
  final String taskId;
  final String title;
  final String description;
  final String status;
  final DateTime startTime;
  final DateTime endTime;
  final Color color;
  final bool isShared;
  final Future<String?>? sharedUserName;

  const _TaskCard({
    required this.taskId,
    required this.title,
    required this.description,
    required this.status,
    required this.startTime,
    required this.endTime,
    required this.color,
    this.isShared = false,
    this.sharedUserName,
  });

  String _formatTime(DateTime time) => DateFormat('h:mm a').format(time);

  String _getDuration() {
    final duration = endTime.difference(startTime);
    if (duration.inHours > 0) {
      return '${duration.inHours}h ${duration.inMinutes.remainder(60)}m';
    }
    return '${duration.inMinutes}m';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 10.w),
      child: Container(
        decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 6,
                  offset: const Offset(0, 3))
            ]),
        child: Padding(
          padding: EdgeInsets.all(16.sp),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 20.sp,
                                fontWeight: FontWeight.w600),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                        if (isShared)
                          FutureBuilder<String?>(
                            future: sharedUserName,
                            builder: (context, snapshot) {
                              if (snapshot.connectionState ==
                                  ConnectionState.waiting) {
                                return SizedBox(height: 4.h);
                              }
                              return Text(
                                'Shared by ${snapshot.data ?? 'user'}',
                                style: GoogleFonts.poppins(
                                  color: Colors.white.withOpacity(0.8),
                                  fontSize: 12.sp,
                                ),
                              );
                            },
                          ),
                      ],
                    ),
                  ),
                  DropdownButton<String>(
                    value: status,
                    dropdownColor: color,
                    underline: const SizedBox(),
                    style: GoogleFonts.poppins(
                        color: Colors.white, fontSize: 14.sp),
                    items: ['Pending', 'Completed', 'In Progress']
                        .map((String value) => DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            ))
                        .toList(),
                    onChanged: (value) async {
                      if (value != null) {
                        await FirebaseFirestore.instance
                            .collection('users')
                            .doc(FirebaseAuth.instance.currentUser?.uid)
                            .collection('taskID')
                            .doc(taskId)
                            .update({'status': value});
                      }
                    },
                  ),
                ],
              ),
              if (description.isNotEmpty) ...[
                SizedBox(height: 8.h),
                Text(description,
                    style: GoogleFonts.poppins(
                        color: Colors.white.withOpacity(0.9), fontSize: 14.sp)),
              ],
              SizedBox(height: 12.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_formatTime(startTime),
                          style: GoogleFonts.poppins(
                              color: Colors.white, fontSize: 18.sp)),
                      Text('Start',
                          style: GoogleFonts.poppins(
                              color: Colors.white.withOpacity(0.8),
                              fontSize: 12.sp)),
                    ],
                  ),
                  Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                    decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20)),
                    child: Text(_getDuration(),
                        style: GoogleFonts.poppins(
                            color: Colors.white, fontSize: 14.sp)),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_formatTime(endTime),
                          style: GoogleFonts.poppins(
                              color: Colors.white, fontSize: 18.sp)),
                      Text('End',
                          style: GoogleFonts.poppins(
                              color: Colors.white.withOpacity(0.8),
                              fontSize: 12.sp)),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
     ),
);
}
}
