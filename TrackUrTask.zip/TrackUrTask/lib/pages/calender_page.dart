import 'package:calender_app/pages/add_task.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:date_picker_timeline/date_picker_widget.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';

class CalenderPage extends StatefulWidget {
  const CalenderPage({super.key});

  @override
  State<CalenderPage> createState() => _CalenderPageState();
}

class _CalenderPageState extends State<CalenderPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  DateTime _selectedDate = DateTime.now();
  List<Map<String, dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _fetchTasks();
  }

  Future<void> _fetchTasks() async {
    User? user = _auth.currentUser;
    if (user == null) return;

    String userID = user.uid;
    DateTime startOfDay = DateTime(_selectedDate.year, _selectedDate.month, _selectedDate.day);
    DateTime endOfDay = startOfDay.add(const Duration(days: 1));

    try {
      List<Map<String, dynamic>> fetchedTasks = [];

      QuerySnapshot userTasks = await _firestore
          .collection('users')
          .doc(userID)
          .collection('taskID')
          .where('startDateTime', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
          .where('startDateTime', isLessThan: Timestamp.fromDate(endOfDay))
          .get();

      fetchedTasks.addAll(userTasks.docs.map((doc) => doc.data() as Map<String, dynamic>));

      // Find users who have shared their tasks with the current user
      QuerySnapshot sharedUsers = await _firestore
          .collection('users')
          .where('sharedWith', arrayContains: userID)
          .get();

      for (var doc in sharedUsers.docs) {
        String sharedUserID = doc.id;

        QuerySnapshot sharedTasks = await _firestore
            .collection('users')
            .doc(sharedUserID)
            .collection('taskID')
            .where('startDateTime', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
            .where('startDateTime', isLessThan: Timestamp.fromDate(endOfDay))
            .get();

        fetchedTasks.addAll(sharedTasks.docs.map((doc) => doc.data() as Map<String, dynamic>));
      }

      setState(() {
        _tasks = fetchedTasks;
      });

      print("Tasks fetched: ${_tasks.length}");
    } catch (e) {
      print("Error fetching tasks: $e");
    }
  }

  void _showShareDialog() {
    TextEditingController emailController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Share Tasks"),
        content: TextField(
          controller: emailController,
          decoration: const InputDecoration(hintText: "Enter user's email"),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          TextButton(
            onPressed: () async {
              String email = emailController.text.trim();
              if (email.isNotEmpty) {
                await _addSharedUser(email);
              }
              Navigator.pop(context);
            },
            child: const Text("Share"),
          ),
        ],
      ),
    );
  }

  Future<void> _addSharedUser(String email) async {
    try {
      QuerySnapshot usersQuery = await _firestore
          .collection('users')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();

      if (usersQuery.docs.isNotEmpty) {
        String sharedUserID = usersQuery.docs.first.id;
        String currentUserID = _auth.currentUser!.uid;

        await _firestore.collection('users').doc(currentUserID).update({
          'sharedWith': FieldValue.arrayUnion([sharedUserID])
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Tasks shared with $email successfully!")),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("User not found!")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error sharing tasks: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SlidingUpPanel(
        maxHeight: 750,
        defaultPanelState: PanelState.OPEN,
        isDraggable: false,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
        panel: Padding(
          padding: const EdgeInsets.only(top: 20, left: 5, right: 5),
          child: Column(
            children: [
              // Navigation Bar with Share & Add Task Buttons
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pushNamed(context, '/todayPage'),
                          child: Container(
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(),
                              borderRadius: BorderRadius.circular(24),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20),
                              child: Center(
                                child: Text(
                                  "Today",
                                  style: GoogleFonts.poppins(color: Colors.black, fontSize: 16),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Container(
                          height: 50,
                          decoration: BoxDecoration(
                            color: const Color(0xFF80DEEA),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: Center(
                              child: Text(
                                "Calendar",
                                style: GoogleFonts.poppins(color: Colors.white, fontSize: 16),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.person_add, color: Colors.black),
                          onPressed: _showShareDialog,
                        ),
                        FloatingActionButton(
                          backgroundColor: Colors.blue,
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => AddTaskPage()),
                          ).then((_) => _fetchTasks()),
                          child: const Icon(Icons.add, color: Colors.white),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              DatePicker(
                DateTime.now(),
                initialSelectedDate: _selectedDate,
                selectionColor: Colors.blue,
                selectedTextColor: Colors.white,
                onDateChange: (date) {
                  setState(() {
                    _selectedDate = date;
                    _fetchTasks();
                  });
                },
              ),

              const SizedBox(height: 20),

Expanded(
  child: _tasks.isEmpty
      ? const Center(child: Text("No tasks available"))
      : ListView.builder(
          itemCount: _tasks.length,
          itemBuilder: (context, index) {
            Map<String, dynamic> task = _tasks[index];

            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                elevation: 3,
                color: Colors.white, // Soft background color
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.blueAccent.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.task, color: Colors.blueAccent),
                  ),
                  title: Text(
                    task['title'] ?? "Untitled Task",
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  subtitle: Text(
                    "Due: ${DateFormat('EEE, MMM d, HH:mm').format((task['startDateTime'] as Timestamp).toDate())}",
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                      color: Colors.grey[700],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
),
            ],
          ),
        ),
      ),
    );
  }
}
